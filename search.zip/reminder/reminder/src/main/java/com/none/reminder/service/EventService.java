package com.none.reminder.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.none.reminder.entity.EventEntity;

import java.util.List;

/**
 * desc event操作服务接口
 */
public interface EventService extends IService<EventEntity> {
    List<EventEntity> searchByKeyword(String keyword);
}
