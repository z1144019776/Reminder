package com.none.reminder.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.none.reminder.dao.EventDao;
import com.none.reminder.entity.EventEntity;
import com.none.reminder.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("eventService")
public class EventServiceImpl extends ServiceImpl<EventDao, EventEntity> implements EventService {

    @Override
    public List<EventEntity> searchByKeyword(String keyword) {
        return this.list(new QueryWrapper<EventEntity>().like("event", keyword));
    }
    
}
