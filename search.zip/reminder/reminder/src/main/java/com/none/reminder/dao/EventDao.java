package com.none.reminder.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.none.reminder.entity.EventEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * desc event操作接口
 * 
 */
@Mapper
public interface EventDao extends BaseMapper<EventEntity> {
    
}
