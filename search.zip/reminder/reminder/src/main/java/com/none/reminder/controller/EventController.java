package com.none.reminder.controller;

import com.none.reminder.common.R;
import com.none.reminder.entity.EventEntity;
import com.none.reminder.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/event")
public class EventController {

    @Autowired
    private EventService eventService;

    @GetMapping("/test")
    public String test() {
        return "just for test.";
    }

    @GetMapping("/search")
    public R searchByKeyword(@RequestParam("keyword") String keyword) {
        if (StringUtils.isEmpty(keyword)) {
            return R.error("检索关键字不能为空");
        }
        List<EventEntity> eventEntityList = eventService.searchByKeyword(keyword);
        for (EventEntity eventEntity : eventEntityList) {
            System.out.println(eventEntity.getId() + "-" + eventEntity.getEvent() + "---" + eventEntity.getEventTime());
        }
        return R.ok().put("eventList", eventEntityList);
    }

}
