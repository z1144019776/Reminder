package com.none.reminder.exception;

import com.none.reminder.common.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice(basePackages = "com.none.reminder.controller")
public class GlobalControllerAdvice {
    @ExceptionHandler(value = Throwable.class)
    public R handleException(Throwable throwable) {
        log.error("系统出现未知异常:", throwable);
        return R.error(500, "系统未知异常");
    }
}
