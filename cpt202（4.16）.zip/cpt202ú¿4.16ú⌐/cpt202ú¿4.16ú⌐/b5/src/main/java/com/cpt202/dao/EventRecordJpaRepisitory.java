package com.cpt202.dao;

import com.cpt202.model.EventRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EventRecordJpaRepisitory extends JpaRepository<EventRecord, Long> {


    List<EventRecord> getEventRecordsByEventNameContains(String name);
}
