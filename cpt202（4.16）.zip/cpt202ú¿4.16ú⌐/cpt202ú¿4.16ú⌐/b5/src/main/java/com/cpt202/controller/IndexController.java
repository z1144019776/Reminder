package com.cpt202.controller;

import com.cpt202.model.Event;
import com.cpt202.model.EventRecord;
import com.cpt202.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpSession;

@Controller
public class IndexController {

    @Autowired
    private EventService eventService;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm");


    @RequestMapping("/")
    public String hello(Model model) {
        return "index";
    }

    @RequestMapping("/home")
    public String calendarHome(Model model) {
        return "calendar-home";
    }


    @RequestMapping("/list")
    public String eventList(Model mode, @RequestParam(value = "title",required = false) String title) {
        List<EventRecord> eventList = eventService.getEventRecordList(title);
        mode.addAttribute("list", eventList);
        mode.addAttribute("title", title);
        return "calendar-list.html";
    }

    @RequestMapping("/deleteEvent/{id}")
    private String deleteEvent(@PathVariable Long id){
        eventService.deleteEvent(id);
        return "redirect:/home";
    }


    @RequestMapping("/selectEventRecord")
    @ResponseBody
    public List<EventRecord> getEventList() {
        return eventService.getEventRecordList(null);
    }

    @RequestMapping("/saveEventRecord")
    @ResponseBody
    public Long saveEventRecord(@RequestParam(name = "eventName") String eventName,
                               @RequestParam(name = "startTime") String startTime,
                               @RequestParam(name = "endTime") String endTime,
                               HttpSession session) {
        // 从session中获取邮箱，需要和登录结合使用
        String email = (String) session.getAttribute("email");
        if (StringUtils.isEmpty(email)) {
            // 为了测试这里暂时可以是你自己的邮箱
            email = "1351566457@qq.com";
        }

        EventRecord eventRecord = new EventRecord();
        eventRecord.setEventName(eventName);
        try {
            eventRecord.setStartTime(dateFormat.parse(startTime));
            eventRecord.setEndTime(dateFormat.parse(endTime));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        EventRecord savedevent = eventService.saveEventRecord(eventRecord, email);
        return savedevent.getId();
    }


}
