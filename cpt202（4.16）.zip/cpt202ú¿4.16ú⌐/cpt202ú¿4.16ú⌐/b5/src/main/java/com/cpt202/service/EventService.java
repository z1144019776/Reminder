package com.cpt202.service;

import antlr.StringUtils;

import com.cpt202.component.CronComponent;
import com.cpt202.dao.EventJpaRepository;
import com.cpt202.dao.EventRecordJpaRepisitory;
import com.cpt202.model.Event;
import com.cpt202.model.EventRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class EventService {

    @Autowired
    private CronComponent cronComponent;

    @Autowired
    private EventJpaRepository eventJpaRepository;

    @Autowired
    private EventRecordJpaRepisitory eventRecordJpaRepisitory;

    /**
     * 事件保存
     */
    public Event saveEvent(Event event) {
        return eventJpaRepository.save(event);
    }

    /**
     * 时间查询
     */
    public List<Event> getEventList() {
        return eventJpaRepository.findAll();
    }

    public void deleteEvent(Long id) {
        eventRecordJpaRepisitory.deleteById(id);
    }

    /**
     * 保存日历
     *
     * @param eventRecord
     * @return
     */
    public EventRecord saveEventRecord(EventRecord eventRecord, String email) {
        // 获取事件的开始时间
        Date targetDate = eventRecord.getStartTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(targetDate);
        // 提前一小时提醒
        calendar.add(Calendar.HOUR, -1);
        targetDate = calendar.getTime();

        // 设置定时任务发送邮件
        cronComponent.cronJob(targetDate, email, eventRecord.getEventName());
        return eventRecordJpaRepisitory.save(eventRecord);
    }

    /**
     * 时间查询
     */
    public List<EventRecord> getEventRecordList(String title) {
        if (title == null || title.equals("")) {
            return eventRecordJpaRepisitory.findAll();
        } else {
            return eventRecordJpaRepisitory.getEventRecordsByEventNameContains(title);
        }
    }

}
