package com.cpt202.controller;

import com.cpt202.model.Event;
import com.cpt202.model.EventRecord;
import com.cpt202.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@Controller
public class IndexController {

    @Autowired
    private EventService eventService;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm");


    @RequestMapping("/")
    public String hello(Model model) {
        return "index";
    }

    @RequestMapping("/selectEventRecord")
    @ResponseBody
    public List<EventRecord> getEventList() {
        return eventService.getEventRecordList();
    }

    @RequestMapping("/saveEventRecord")
    @ResponseBody
    public int saveEventRecord(@RequestParam(name = "eventName") String eventName,
                               @RequestParam(name = "startTime") String startTime,
                               @RequestParam(name = "endTime") String endTime) {
        EventRecord eventRecord = new EventRecord();
        eventRecord.setEventName(eventName);
        try {
            eventRecord.setStartTime(dateFormat.parse(startTime));
            eventRecord.setEndTime(dateFormat.parse(endTime));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        eventService.saveEventRecord(eventRecord);
        return 1;
    }


}
