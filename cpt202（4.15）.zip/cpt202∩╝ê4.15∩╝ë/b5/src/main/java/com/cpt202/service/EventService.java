package com.cpt202.service;

import com.cpt202.dao.EventJpaRepository;
import com.cpt202.dao.EventRecordJpaRepisitory;
import com.cpt202.model.Event;
import com.cpt202.model.EventRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {

    @Autowired
    private EventJpaRepository eventJpaRepository;

    @Autowired
    private EventRecordJpaRepisitory eventRecordJpaRepisitory;

    /**
     * 事件保存
     */
    public Event saveEvent(Event event) {
        return eventJpaRepository.save(event);
    }

    /**
     * 时间查询
     */
    public List<Event> getEventList() {
        return eventJpaRepository.findAll();
    }

    /**
     * 保存日历
     *
     * @param eventRecord
     * @return
     */
    public EventRecord saveEventRecord(EventRecord eventRecord) {
        return eventRecordJpaRepisitory.save(eventRecord);
    }

    /**
     * 时间查询
     */
    public List<EventRecord> getEventRecordList() {
        return eventRecordJpaRepisitory.findAll();
    }

}
