package com.study.studentsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsysApplicationTests {

    @Test
    void contextLoads() {
    }

}
