package com.study.studentsys.constant;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EmailConstant {

    public static final Map<String, String> EMAIL_CODE_MAP = new ConcurrentHashMap<>();

}
