// JavaScript Document
console.log("userEmail.js loaded");
// 之后你有后端的时候，
// 把邮箱地址发送到这里：